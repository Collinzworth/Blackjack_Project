/******************************************************************************

               Intro to Java:  Mini Project 2- Blackjack
                            Aaron Collinsworth
                              04/07/2020

           Purpose: Create a game of blackjack where a user can add players and bet on hands against a dealer.

*******************************************************************************/

import java.util.ArrayList;
import java.util.Scanner;

public class Main
{

   /**main
    * Contains setup and the loop which the game is played within
   * @return void
    **/

   public static void main(String [] args)
   {

      boolean play = true;

      DeckOfCards deck = new DeckOfCards();
      ArrayList<Person> people = new ArrayList<Person>();
      ArrayList<Player> players = new ArrayList<Player>();
      
      Dealer dealer = new Dealer();
      people.add(dealer);

      // Prompt user to add players to the game
      addPlayers(people, players);

      // While game is being played, deal hands
      while(play)
      {

         // Need to initialize player flags
         for(Person person : people)
         { // Initialize each person's status's 
             person.initialize();
         }

         showBalances(players);
         setBets(players);
         dealHand(people, deck);
         showTable(people);

         tableRotation(people, players, deck);
         dealer.dealerPlay(people, deck);
         determineWinners(dealer, players);
         showBalances(players);
         System.out.println("");

         removePerson(people, players);
         if(people.size() == 1)
         { // If no people left set play to false and exit game
            System.out.println("No people left playing");
            play = false;
         } else
         { // Prompt user if they want to continue playing
            System.out.println("Play another hand (y/n)?:");
            play = userChoose();
         }

      } // End while

      System.out.println("Thank you for playing!");

   } // End Main Method

/********************************************************************************/
// Play Methods

   /**setsBets 
    *Goes around the table and takes players bets
   *@param Player players --> array list
   * @return void
    **/

    public static void setBets(ArrayList<Player> players)
    {

      for(Player player : players)
      {
         player.setBetAmount();
      }

   } // End setBets()

   /**dealHand 
    *Goes around the table and takes players bets
   *@param Person people --> array list
   *@param Player players --> array list
   * @return void
    **/

   public static void dealHand(ArrayList<Person> people, DeckOfCards deck)
   {

         final int numCardsToDeal = 2;

         System.out.println("New Deal");
         System.out.println("--------");

         for(int i = 1; i <= numCardsToDeal; i++)
         {
            for(Person person : people)
            {
               person.dealCard(deck);
            }
         } // End For

   } // End dealHand

   /**tableRotation 
    *Goes around the table for each persons hand
   *@param Person people --> array list
   *@param Player players --> array list
   *@param DeckOfCards deck 
   * @return void
    **/

   public static void tableRotation(ArrayList<Person> people,ArrayList<Player> players,
   DeckOfCards deck )
   {

      for(Player player : players)
      {

         if (player.getHandVal() == 21)
         { // If player has 21 on initial flip, they win automatically
            player.setWinStatus(true);
            player.setBetAmount(1.5);
            System.out.println(player.getName() + " hit blackjack!");
         } else
         { // Else they must play their hand
            player.playHand(people, deck);
         } // End if

       } // End for

   } // End tableRotation()

   /**determineWinners 
    * Goes around the table and determines if each player has a hand greater than the dealers and less than 21
   *@param Dealer dealer
   *@param Player players --> array list
   * @return void
    **/

   public static void determineWinners(Dealer dealer, ArrayList<Player> players)
   {

      System.out.println("");            
      System.out.println("Outcome");
      System.out.println("-------");

      for(Player player : players)
      {

         if(player.getwinStatus() == true)
            player.setWinStatus(true);
            player.setBalance();
            System.out.println(player.getName() + " Wins!");

         else if(player.getBustStatus() == true)
         {

            player.setWinStatus(false);
            player.setBalance();
            System.out.println(player.getName() + " Loses");

         } else if(player.getHandVal() > dealer.getHandVal() && player.getHandVal() <= 21)
         {

            player.setWinStatus(true);
            player.setBalance();
            System.out.println(player.getName() + " Wins!");

         } else if(player.getHandVal() <= 21 && dealer.getHandVal() > 21 )
         {
            player.setWinStatus(true);
            player.setBalance();
            System.out.println(player.getName() + " Wins!");

         } else if(player.getHandVal() < dealer.getHandVal() && dealer.getHandVal() <= 21 )
         {

            player.setWinStatus(false);
            player.setBalance();
            System.out.println(player.getName() + " Loses");

         } else if(player.getHandVal() == dealer.getHandVal() && dealer.getHandVal() <= 21)
         {
            System.out.println(player.getName() + " Push");
         } // End if   

         player.setWinStatus(false);

      } // End for

   } // End determineWinners

/********************************************************************************/
// Display Methods

   /**showTable
    * Shows hands of all people on the table, dealer only displays 1 card
   *@param Person people --> array list
   * @return void
    **/

   public static void showTable(ArrayList<Person> people)
   {

      boolean first = true;
      for(Person personToDeal : people)
      {
         if(first == true)
         {
            personToDeal.showHand(1);
            first = false;
         } else
         {
            personToDeal.showHand();
         }
      } // End For

   } // End showTable

   /**showTable
    * Shows hands of all people on the table
   * @Override
   *@param Person people --> array list
   *@param boolean reveal --> if true all cards are revealed
   * @return void
    **/

   public static void showTable(ArrayList<Person> people, boolean reveal)
   {

      System.out.println("");
      for(Person personToDeal : people)
      {
          personToDeal.showHand();
      }

   } // End ShowTable

   /**showBalances 
    * Shows chip balances of all remaining players
   *@param Player players --> array list
   * @return void
    **/

   public static void showBalances(ArrayList<Player> players)
   {

      System.out.println("");
      System.out.println("Player Balances");
      System.out.println("---------------");

      for(Player player : players)
      { // Loop through players and display their balance
         player.displayBalance();
         if(player.getBalance() == 0)
         { // If players balance is 0, remove them from the game
             System.out.println(player.getName() + " is out of chips!");
             System.out.println(player.getName() + " removed");
         } // End if

      } // End for

    } // End showBalances()

/********************************************************************************/
// Utillity Methods

   /**addPlayers 
    * Prompts user to add players and adds them to an array list
   *@param Person people --> array list
   *@param Player players --> array list
   * @return void
    **/

   public static void addPlayers(ArrayList<Person> people,ArrayList<Player> players)
   {

      boolean addPlayer = true;
      String playerName;
      
      Scanner input = new Scanner(System.in);
 
      do
      { // Prompt user to add players
         
         if(addPlayer == true)
         { // If player is added, create new player and add to array lists
           
            System.out.print("Enter Player Name:");
            playerName = input.nextLine();

            Player player = new Player(playerName);
            people.add(player);
            players.add(player);
            
         } // End if

         System.out.print("Do you want to add another player (y/n)?:");
         addPlayer = userChoose();
         System.out.println("");

    } while(addPlayer == true);

   } // End addPlayers()

   /**
   * removePerson
   * Removes person if they lose all their chips
   *
   *@param persons- arraylist of persons
   *@param players- arraylist of players
   * @return void
   */

   public static void removePerson(ArrayList<Person> people, ArrayList<Player> players)
   {

      int j;
      int k;
      
      Person person;
      Player player;
    
      k = players.size();
      
      for(int i = 0; i < k; i++)
      {

         j = i + 1;

         person = people.get(j);
         player = players.get(i);

         if(player.getBalance() == 0)
         {
            people.remove(j);
            players.remove(i);
            k = k - 1;
         }

      } // End For

   } // End removeperson

   /**userChoose 
    * Prompts user to enter a choice yes or no
   * @return boolean
    **/

   public static boolean userChoose()
   {

      char userChoice;

      // Use a Scanner to prompt for user input
      Scanner input = new Scanner(System.in);
      userChoice = input.next().charAt(0); // Character input symbolizing yes or no

      // Switch case to determine if game will continue to be played
      switch(userChoice)
      {
            // Yes selected
            case 'y':
            case 'Y':
               System.out.println("");
               return true;

            // No selected
            case 'n':
            case 'N':
               return false;

            // No is chosen by default
            default:
               return false;
      } // End switch

   } // End userChoose

} // End Main Class
