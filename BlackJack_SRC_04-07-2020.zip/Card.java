﻿/**
   An object of class card represents one of the 52 cards in a
   standard deck of playing cards.  Each card has a suit and
   a value.

   @Author: Aaron Collinsworth
   @Version: 1.0.0
*/

import java.util.ArrayList;

public class Card 
{

   public String cardString;

   private int rankVal;
   private String cardVal;
   private char cardSuit;

   /** valArray
   valArray integer array looks up integer value of the card
    **/

   public final int valArray[] = {11,2,3,4,5,6,7,8,9,10,10,10,10,
                                  11,2,3,4,5,6,7,8,9,10,10,10,10,
                                  11,2,3,4,5,6,7,8,9,10,10,10,10,
                                  11,2,3,4,5,6,7,8,9,10,10,10,10};
                                  
   /** RankArray
    rankArray string array looks up corresponding ascii character for suit
    **/

   public final String rankArray[] = {"A","2","3","4","5","6","7","8","9","10","J","Q","K",
                                      "A","2","3","4","5","6","7","8","9","10","J","Q","K",
                                      "A","2","3","4","5","6","7","8","9","10","J","Q","K",
                                      "A","2","3","4","5","6","7","8","9","10","J","Q","K"};

   /** suitArray
   * suitArray char array looks up corresponding ascii character for suit
   **/


   public final char suitArray[] = {'\u2660','\u2660','\u2660','\u2660','\u2660','\u2660',
                                    '\u2660','\u2660','\u2660','\u2660','\u2660','\u2660',
                                    '\u2660','\u2764','\u2764','\u2764','\u2764','\u2764',
                                    '\u2764','\u2764','\u2764','\u2764','\u2764','\u2764',
                                    '\u2764','\u2764','\u2666','\u2666','\u2666','\u2666',
                                    '\u2666','\u2666','\u2666','\u2666','\u2666','\u2666',
                                    '\u2666','\u2666','\u2666','\u2663','\u2663','\u2663',
                                    '\u2663','\u2663','\u2663','\u2663','\u2663','\u2663',
                                    '\u2663','\u2663','\u2663','\u2663'};


    /** Card Constructor
    * Calls initial sets and sets the card rank/value/suit
   * @param inputVal
    **/

   public Card(int inputVal) 
   {

      setRank(inputVal);
      setRankVal(inputVal);
      setSuit(inputVal);

   } // End Card Constructor

/********************************************************************************/

   /** setRank
    * Sets rank of the card (face value)
   * @return void
    **/

   private void setRank(int inputVal) 
   {
      cardVal = rankArray[inputVal];
   } // End setRank

   /** getRank
    * Gets rank of the card (face value)
   * @return String
    **/

   public String getRank() 
   {
      return cardVal;
   } // End getRank()

/********************************************************************************/

   /** setRankVal
   * @param inputVal
   * @return void
    * Override setRankVal to change ace value to 1 if hand exceeds 21
    **/

   public void setRankVal(int inputVal)
   { // Set teh value of the rank
      rankVal = valArray[inputVal];
   } // End setRankVal
   
   /** setRankVal
    * Override setRankVal to change ace value to 1 if hand exceeds 21
    * @Override
   * @param aceLow
   * @return void
    **/

   public void setRankVal(boolean aceLow)
   {
       if(aceLow = true)
       { 
           rankVal = 1;

       }else
       {
           rankVal = 11;
       }

   } // End setRankVal

   /** getRankVal()
    * Sets rank value for car (1 - 11)
   * @param inputVal
   * @return void
    **/

   public int getRankVal() 
   {
      return rankVal;
   } // End getRankVal()

/********************************************************************************/

   /** setSuit
    * Sets suit of the card (Spade, Club, Diamond, Heart)
   * @param inputVal
   * @return void
    **/

   private void setSuit(int inputVal) 
   { // Sets suit of card
      cardSuit = suitArray[inputVal];
   } // End setSuit

   /** getSuit
    *Gets suit of the card (Spade, Club, Diamond, Heart)
   * @return String
    **/

   public int getSuit() 
   {
      return cardSuit;
   } // End getSuit

/********************************************************************************/

   /** getCardString
    *Gets string representing card with the face value and suit
   * @return String
    **/

   public String getCardString() 
   {
      // Return a String representing the card's value.
      cardString = getRank() + (char) getSuit();
      return cardString;
   } // End getCardString

} // end  Card class