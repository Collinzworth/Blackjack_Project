/** Dealer Class
   * 
   * Dealer of a game of blackjack that plays by dealer rules
   *@Author: Aaron Collinsworth
*/

import java.util.ArrayList;

public class Dealer extends Person
{

   public String name;

/********************************************************************************/
// Initialization Methods

   /** Dealer Constructor
    * Creates a Dealer with the default name "Dealer"
    **/

   public Dealer()
   {

      super();
      setName("Dealer");

   } // End Constructer -> Dealer()

/********************************************************************************/
// Play Methods

   /**
   * dealerHand
   * Method plays dealers hand at the end of the table rotation
   *
   *@param people- arraylist of persons
   *@param deck- Deck of cards composed of an array list of cards.
   * @return void
   */

   public void dealerPlay(ArrayList<Person> people, DeckOfCards deck)
   {

      int handVal;
      boolean hit = false;
      boolean bust = false; 

      System.out.println("");
      System.out.println("Dealer Turn");
      System.out.println("-----------");

      while(getHandVal() < 17)
      {

         dealCard(deck);
         getHandVal();

         if(getHandVal() > 21)
         {
            bust = true;
            setBustStatus(bust);
            setWinStatus(false);
            System.out.println(getName() + " BUSTED!");
            System.out.println("");
         } else if(getHandVal() == 21)
         {
            System.out.println("");
            setWinStatus(true);
         } else if (getHandVal() < 17)
         {
            dealCard(deck);
          } // End if

      } // End dealer hitting

      if(getHandVal() == 21)
      {
         setWinStatus(true);
      }

      Blackjack.showTable(people,true);

   } // End dealerPlay

/********************************************************************************/
// Display Methods

   /**
   * showHand
   * Overrides showHand method for dealer. Any integer entered into the method as an argument will cause the dealer to display 1 card.
   *
   *@Override
   *@param numCards
   * @return void
   */

   public void showHand(int numCards)
   {

      handString = (hand.get(0)).getCardString();
      System.out.println(getName() + ": "+ handString + "-> ??");

   } // End showHand()

} // End Dealer Class
