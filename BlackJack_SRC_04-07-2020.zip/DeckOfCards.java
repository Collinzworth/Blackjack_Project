/** DeckOfCards Class
   * 
   * Creates a deck of cards  object that can be drawn from
   *@Author: Aaron Collinsworth
*/

import java.util.ArrayList;
import java.util.Random;

public class DeckOfCards
{

   private int numOfCards = 52;
   private int createIndex;
   private int deckIndex;
   public Card currentCard;

   public ArrayList<Card> deckOfCards;

/********************************************************************************/
// Initialization Methods

   /**DeckOfCards Constructor
    * Creates a deck of cards that can be drawn from
    **/

   public DeckOfCards()
   {
      // Initialize deck - create array list of all cards in deck
      deckOfCards = new ArrayList<Card>(numOfCards);
      for(int i = 1; i <= numOfCards; i++) 
      {
         createIndex = i - 1;
         Card addCard = new Card(createIndex);
         deckOfCards.add(addCard);
      } // End For

   } // End DeckOfCards()

/********************************************************************************/
// Play Methods

   /**dealCards Method
    * Removes a card from the deck and gives it to a player
   *@return Card currentCard
    **/

   public Card dealCard()
   {
      int rand = (int) (Math.random() * deckOfCards.size() ); //deckOfCards.size());
      currentCard = deckOfCards.get(rand);
      deckOfCards.remove(rand);

      return currentCard;
   } // End dealCard()

} // End DeckOfCards Class
