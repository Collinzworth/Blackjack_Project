/** Person Class
   * 
   * Parent Class- Person in a game of blackjack, rules are defined by sub  classes
   *@Author: Aaron Collinsworth
**/

import java.util.ArrayList;

public class Person
{

   final int aceSwapThresh = 21; // Determines amount to change ace value if hit exceeds

   private int currentVal;

   private String name;
   public String handString = "";

   private int handVal;
   private boolean aceChanged = false;
   private boolean bustStatus = false;
   private boolean winStatus = false;

   public ArrayList<Card> hand;

/********************************************************************************/
// Initialization Methods

   /** Person Constructor
    * Creates a Person with the default name
   * Static variables keep track of the amount of people that are created
    **/

   public Person()
   {

      // Initialize person, new hand and all flags to false
      initialize();

   } // End Person Constructor

   /** initialize
    * Initializes a persons flags to false and clears their hand
   * @return void
    **/

   public void initialize()
   {

      // Initialize deck - create array list of all cards in deck
      hand = new ArrayList<Card>();
      aceChanged = false;
      bustStatus = false;
      winStatus = false;

   } // End initialize


/********************************************************************************/
// Name Methods

   /** setName
    * Sets the name of the person
   *@param name
   * @return void
    **/

   public void setName(String name)
   {
        this.name = name;   
   } // End setName()
   
   /** getName
    * Gets the name of the person
   *@param name
   * @return void
    **/

   public String getName()
   {
      return name;
   } // End getName()


/********************************************************************************/
// Card Methods

   /**
    * dealCard
   *  Deals a person a card
    * @param deck
   * @return void
    **/

   public void dealCard(DeckOfCards deck)
   {
      Card newCard; //= new Card();
      newCard = deck.dealCard();
      hand.add(newCard);
   } // End dealCard

   /**
    * calcHandVal
   *  Calculates the numerical value of the persons cards
   * @return void
    **/

   public int calcHandVal()
   {

      boolean ace = false;

      // Calculate the initial cumulative  value of the cards
      handVal = 0;
      for(Card currentCard : hand)
      {
         handVal += currentCard.getRankVal();
      }

      // Check if there is an ace in the persons hand
      ace = checkForAce();

      // If the person has exceeded 21 and has an ace,  swap the ace value from 11 to 1
      while(handVal > 21 && ace == true)
      {
          changeAceVal();
          handVal = getHandVal();
      }

      return handVal;

   } // End calcHandVal()

   /**
    * getHandVal
   *  Gets the numerical value of the persons cards
   * @return int
    **/

   public int getHandVal()
   {
      return calcHandVal();
   } // end getHandVal()

/********************************************************************************/
// Ace value swap Methods

   /**
    * checkForAce
   *  Gets a true/false if an ace is present in persons hand
   * @return boolean
    **/

   private boolean checkForAce()
   {

      for(Card currentCard : hand)
      {
         if(currentCard.getRankVal() == 11)
         {
            return true;
         }
      } // end For

      return false;

   } // End checkForAce

   /**
    * changeAceVal()
   * Determines if an aces value needs to be swapped from 11 to 1
   * @return void
    **/

   private void changeAceVal()
   {
      aceChanged = false;
      //handVal = 0;
      for(Card currentCard : hand)
      { // Determine if there is an ACE

         currentVal = currentCard.getRankVal();

         if(currentVal == 11 && aceChanged == false)
         { // If this card is an ace and value is greater than 21, change value to 1
            currentCard.setRankVal(true);
            aceChanged = true;
         }

      } // End For

   } // End changeAceVal()

/********************************************************************************/
// Bust Methods

   /**
    * setBustStatus()
   * Sets flag if player has exceeded 21 points
   * @param bust
   * @return void
    **/

   public void setBustStatus(boolean bust)
   {
       if(bust == true)
       {
           bustStatus = true;
       }
   } // End setBustStatus

   /**
    * getBustStatus()
   * Gets status if player has busted
   * @return bustStatus
    **/

   public boolean getBustStatus()
   {
        return bustStatus;
   } // End getBustStatus

/********************************************************************************/
// Win Methods

   /**
    * setWinStatus()
   * Sets flag if player has won
   * @param win
   * @return void
    **/

   public void setWinStatus(boolean win)
   {
       if(win == true)
       {
           winStatus = true;
       }
   } // setWinStatus

   /**
    * getWinStatus()
   * Gets status if player has busted
   * @return winStatus
    **/

   public boolean getWinStatus()
   {
        return winStatus;
   } // getWinStatus


/********************************************************************************/
// Display Methods

   /**
    * showHand
   * Displays all the cards in a persons hand
   * @return void
    **/

   public void showHand()
   {
         handString = "";
         for( Card currentCard : hand)
         {
            handString = handString + currentCard.getCardString() + " ";
         }
        
         System.out.println(name + ": "+ handString + "-> " + calcHandVal());
   } // End showHand()
  
   public void showHand(int numCards)
   {
   } // End showHand()

} // End Person Class
