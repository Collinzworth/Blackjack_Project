/** Player Class
   * 
   * Sub class of person class that allows a user to player to play hands of blackjack against a dealer
   *@Author: Aaron Collinsworth
**/

import java.util.ArrayList;
import java.util.Random;

import java.util.Scanner;
import java.lang.*;

public class Player extends Person
{

   private int balAmount;
   private int betAmount;
   private boolean bustStatus = false;
   private boolean winStatus = false;

/********************************************************************************/
// Initialization Methods

   /** Player Constructor
    * Creates a player with a name, and chip stack, and a player number
   * @param name
    **/

   public Player(String name)
   {

      super();
    
      balAmount = 1000;

      setName(name);

   } // End Constructer -> Payer()

/********************************************************************************/
// Bet methods

   /** setBetAmount
    * Prompts user to set their bet amount
   * @return void
    **/

   public void setBetAmount()
   {
      do
      {
         // Use a Scanner to prompt for user input
         Scanner input = new Scanner(System.in);
 
         System.out.print(getName() + "'s bet: ");
         betAmount = input.nextInt(); // Character input symbolizing yes or no
         
         if(betAmount > getBalance())
         {
            System.out.println(getName() + "'s bet is larger than their chip stack ");
            System.out.println("Please place another bet");
         } else if(betAmount <= 0)
         {
             System.out.println(getName() + "'s bet is 0 or less");
             System.out.println("Please place another bet");
         }
      } while(betAmount > getBalance() || betAmount <= 0);

   } // End setBetAmount()

   /** setBetAmount
    * sets bet to xBet amount in special cases
   * @return void
    **/
   public void setBetAmount(double multiplyer)
   {
      betAmount = multiplyer * betAmount;
   } // End setBetAmount()


   /** getBet
    * Returns bet amount
   * @return int
    **/

   public int getBet()
   {
        return betAmount;
   } // End getBet()

/********************************************************************************/
// Balance Methods

   /** setBalance
    * Sets the amount of chips a player has
   * @return void
    **/

   public void setBalance()
   {

      if(getWinStatus() == true)
      {
          balAmount = balAmount + getBet();
      }
      else if(getWinStatus() == false)
      {
          balAmount = balAmount - getBet();
      }

   } // End setBalance()

   /** getBalance
    * Gets the amount of chips a player has
   * @return int
    **/

   public int getBalance()
   {
      return balAmount;
   } // End getBalance()

   /** displayBalance
    * Displays the amount of chips a player has
   * @return void
    **/

   public void displayBalance()
   {
      System.out.println(getName() + ": " + getBalance() + " chips" );
   } // End displayBalance()

/********************************************************************************/
// Play Methods

   /**
   * playHand
   * method prompts user to hit or stay
   *
   *@param people- arraylist of persons
   *@param deck- Deck of cards composed of an array list of cards.
   * @return void
   */

    public void playHand(ArrayList<Person> people, DeckOfCards deck)
   {

      //int handVal;
      boolean hit = false;
      boolean bust = false;

      do
      { // Prompt user to hit or stay

         hit = false;
         bust = false;

         System.out.print(getName() + ", do you want to hit? (y/n): ");
         hit = Main.userChoose();

         if(hit == true)
         { // If hit is true deal the player a new card

            dealCard(deck);
            Main.showTable(people);

            if(getHandVal() > 21)
            {
               bust = true;
               setBustStatus(bust);
               setWinStatus(false);
               System.out.println(getName() + " BUSTED!");
               System.out.println("");
               hit = false;
            } else if(getHandVal() == 21)
            {
               setWinStatus(true);
               System.out.println("");
               hit = false;
            } // End if

         } else if(hit == false)
         {
            System.out.println(getName() + " Stays!");
         }// End if

      } while(hit == true && bust == false);

    } // End playHand

} // End Player Class
